<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Barang extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_barang');
	}
	public function index()
	{
		$x['data'] = $this->m_barang->show_barang();
		$this->load->view('v_barang', $x);
	}

	function simpan_barang()
	{
		$kode_barang = $this->input->post('kode_barang');
		$nama_barang = $this->input->post('nama_barang');
		$satuan = $this->input->post('satuan');
		$harga = $this->input->post('harga');
		$this->m_barang->simpan_barang($kode_barang, $nama_barang, $satuan, $harga);
		redirect('barang');
	}

	function edit_barang()
	{
		$kode_barang = $this->input->post('kode_barang');
		$nama_barang = $this->input->post('nama_barang');
		$satuan = $this->input->post('satuan');
		$harga = $this->input->post('harga');
		$this->m_barang->edit_barang($kode_barang, $nama_barang, $satuan, $harga);
		redirect('barang');
	}

	function hapus_barang()
	{
		$kode_barang = $this->input->post('kode_barang');
		$this->m_barang->hapus_barang($kode_barang);
		redirect('barang');
	}
}
