

<?php
class M_barang extends CI_Model
{
    function show_barang()
    {
        $hasil = $this->db->query("SELECT * FROM tbl_barang");
        return $hasil;
    }

    function simpan_barang($kode_barang, $nama_barang, $satuan, $harga)
    {
        $hasil = $this->db->query("INSERT INTO tbl_barang (barang_id,barang_nama,barang_satuan,barang_harga) VALUES ('$kode_barang','$nama_barang','$satuan','$harga')");
        return $hasil;
    }

    function edit_barang($kode_barang, $nama_barang, $satuan, $harga)
    {
        $hasil = $this->db->query("UPDATE tbl_barang SET barang_nama='$nama_barang',barang_satuan='$satuan',barang_harga='$harga' WHERE barang_id='$kode_barang'");
        return $hasil;
    }

    function hapus_barang($kode_barang)
    {
        $hasil = $this->db->query("DELETE FROM tbl_barang WHERE barang_id='$kode_barang'");
        return $hasil;
    }
}
