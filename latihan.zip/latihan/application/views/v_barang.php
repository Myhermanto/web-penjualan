<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="utf-8">

    <title>Data Barang</title>

    <link href="<?php echo base_url() . 'asset/css/bootstrap.css' ?>" rel="stylesheet">

    <link href="<?php echo base_url() . 'asset/css/jquery.dataTables.min.css' ?>" rel="stylesheet">

</head>

<body>
    <div class="container">

        <h1>Data <small>Barang! </small></h1>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">
            Tambah Data
        </button> <br>
        <br>
        <table class="table table-bordered table-striped" id="mydata">

            <thead>

                <tr>

                    <td>Kode Barang</td>

                    <td>Nama Barang</td>

                    <td>Satuan</td>

                    <td>Harga</td>
                    <td>Aksi</td>

                </tr>

            </thead>

            <tbody>

                <?php

                foreach ($data->result_array() as $i) :

                    $barang_id = $i['barang_id'];

                    $barang_nama = $i['barang_nama'];

                    $barang_satuan = $i['barang_satuan'];

                    $barang_harga = $i['barang_harga'];

                ?>

                    <tr>

                        <td><?php echo $barang_id; ?> </td>

                        <td><?php echo $barang_nama; ?> </td>

                        <td><?php echo $barang_satuan; ?> </td>

                        <td><?php echo $barang_harga; ?> </td>
                        <td style="width: 120px;">
                            <a class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal_edit<?php echo $barang_id; ?>"> Edit</a>
                            <a class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modal_hapus<?php echo $barang_id; ?>"> Hapus</a>

                        </td>
                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>
    </div>

    <!-- ============ MODAL ADD BARANG =============== -->

    <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">

        <div class="modal-dialog" role="document">
            <form method="post" action="<?php echo base_url() . 'barang/simpan_barang' ?>">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data Barang</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Kode Barang:</label>
                            <input type="text" class="form-control" name="kode_barang" placeholder="masukan kode barang">
                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Nama Barang:</label>
                            <input type="text" class="form-control" name="nama_barang" placeholder="masukan nama barang">
                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">satuan Barang:</label>
                            <select class="form-control" name="satuan">
                                                                  <option value="Unit">Unit</option>
                                                                    <option value="Kotak">Kotak</option>
                                                                    <option value="Botol">Botol</option>
                                                                    <option value="Sachet">Sachet</option>
                                                                    <option value="Pcs">Pcs</option>
                                                                    <option value="Dus">Dus</option>

                            </select>
                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Harga Barang:</label>
                            <input type="number" class="form-control" name="harga" placeholder="masukan harga barang">
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <!--END MODAL ADD BARANG-->


    <!-- ============ MODAL EDIT BARANG =============== -->
    <?php

    foreach ($data->result_array() as $i) :

        $barang_id = $i['barang_id'];

        $barang_nama = $i['barang_nama'];

        $barang_satuan = $i['barang_satuan'];

        $barang_harga = $i['barang_harga'];

    ?>
        <div class="modal fade" id="modal_edit<?= $barang_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">

            <div class="modal-dialog" role="document">
                <form method="post" action="<?php echo base_url() . 'barang/edit_barang' ?>">

                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Edit Data Barang</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Kode Barang:</label>
                                <input type="text" class="form-control" name="kode_barang" value="<?= $barang_id ?>" placeholder="masukan kode barang">
                            </div>

                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Nama Barang:</label>
                                <input type="text" class="form-control" name="nama_barang" value="<?= $barang_nama ?>" placeholder="masukan nama barang">
                            </div>

                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Satuan Barang:</label>
                                <select class="form-control" name="satuan">

                                                                    <?php if ($barang_satuan == 'Unit') : ?>
                                                                        <option value="Unit" selected>Unit</option>
                                                                        <option value="Kotak">Kotak</option>
                                                                        <option value="Botol">Botol</option>
                                                                        <option value="Sachet">Sachet</option>
                                                                        <option value="Pcs">Pcs</option>
                                                                        <option value="Dus">Dus</option>
                                                                    <?php elseif ($barang_satuan == 'Kotak') : ?>
                                                                        <option value="Unit">Unit</option>
                                                                        <option value="Kotak" selected>Kotak</option>
                                                                        <option value="Botol">Botol</option>
                                                                        <option value="Sachet">Sachet</option>
                                                                        <option value="Pcs">Pcs</option>
                                                                        <option value="Dus">Dus</option>
                                                                    <?php elseif ($barang_satuan == 'Botol') : ?>
                                                                        <option value="Unit">Unit</option>
                                                                        <option value="Kotak">Kotak</option>
                                                                        <option value="Botol" selected>Botol</option>
                                                                        <option value="Sachet">Sachet</option>
                                                                        <option value="Pcs">Pcs</option>
                                                                        <option value="Dus">Dus</option>
                                                                    <?php elseif ($barang_satuan == 'Sachet') : ?>
                                                                        <option value="Unit">Unit</option>
                                                                        <option value="Kotak">Kotak</option>
                                                                        <option value="Botol">Botol</option>
                                                                        <option value="Sachet" selected>Sachet</option>
                                                                        <option value="Pcs">Pcs</option>
                                                                        <option value="Dus">Dus</option>
                                                                    <?php elseif ($barang_satuan == 'Sachet') : ?>
                                                                        <option value="Unit">Unit</option>
                                                                        <option value="Kotak">Kotak</option>
                                                                        <option value="Botol">Botol</option>
                                                                        <option value="Sachet">Sachet</option>
                                                                        <option value="Pcs" selected>Pcs</option>
                                                                        <option value="Dus">Dus</option>
                                                                    <?php else : ?>
                                                                        <option value="Unit">Unit</option>
                                                                        <option value="Kotak">Kotak</option>
                                                                        <option value="Botol">Botol</option>
                                                                        <option value="Sachet">Sachet</option>
                                                                        <option value="Pcs">Pcs</option>
                                                                        <option value="Dus" selected>Dus</option>
                                                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Harga Barang:</label>
                                <input type="number" class="form-control" name="harga" value="<?= $barang_harga ?>" placeholder="masukan harga barang">
                            </div>

                        </div>

                        <div class="modal-footer">

                            <button type="submit" class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    <?php endforeach; ?>


    <!--END MODAL EDIT BARANG-->



       <?php

        foreach ($data->result_array() as $i) :

            $barang_id = $i['barang_id'];

            $barang_nama = $i['barang_nama'];

            $barang_satuan = $i['barang_satuan'];

            $barang_harga = $i['barang_harga'];

        ?>
             
        <!-- ============ MODAL HAPUS BARANG =============== -->
        <div class="modal fade" id="modal_hapus<?= $barang_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">

            <div class="modal-dialog" role="document">
                <form method="post" action="<?php echo base_url() . 'barang/hapus_barang' ?>">

                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Hapus Data Barang</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="hidden" class="form-control" name="kode_barang" value="<?= $barang_id ?>">
                                <p>Apakah Anda yakin ingin menghapus data <?= $barang_nama ?> ini ?</p>
                            </div>



                        </div>

                        <div class="modal-footer">

                            <button type="submit" class="btn btn-primary">Hapus</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
            <?php endforeach; ?>
            
        <!--END MODAL HAPUS BARANG-->


        <script src="<?php echo base_url() . 'asset/js/jquery-2.2.4.min.js' ?>"> </script>

        <script src="<?php echo base_url() . 'asset/js/bootstrap.js' ?>"> </script>

        <script src="<?php echo base_url() . 'asset/js/jquery.dataTables.min.js' ?>"> </script>

        <script src="<?php echo base_url() . 'asset/js/moment.js' ?>"> </script>

        <script>
            $(document).ready(function() {

                $('#mydata').DataTable();

            });
        </script>

</body>

</html>