<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_barang');
	}

	public function index()
	{
		$x['data'] = $this->m_barang->show_barang();

		$this->load->view('index_home', $x);
	}


	function kontak()
	{
		$this->load->view('v_kontak');
	}

	function detail_produk($kode)
	{
		$x['data'] = $this->db->query("SELECT * FROM tbl_barang where barang_id='$kode' ")->row();
		$this->load->view('v_detail_produk', $x);
	}
}
